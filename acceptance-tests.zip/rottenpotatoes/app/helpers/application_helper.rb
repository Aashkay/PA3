# frozen_string_literal: true

# Application Helper
module ApplicationHelper
end
